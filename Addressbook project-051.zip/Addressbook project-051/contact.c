#include "contact.h"
#include <string.h>
#include <ctype.h>


void listContacts(AddressBook *addressBook) {
	printf("\n");
	printf("Si name\t\tphone\t\tmail\n");
	printf("-------------------------------\n");
	for (int i = 0; i < addressBook->contactCount; i++) {
		printf("%d %s\t\t%s\t\t%s\n", i + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
	}
	printf("Contact listed successfully!!!\n");
}

bool isValidName(const char *name) {
	for (int i = 0; name[i] != '\0'; i++) {
		if (!isalpha(name[i]) && name[i] != ' ') {
			return false; 
		}
	}
	return true;
}

bool isValidPhone(const char *phone) {
	if (strlen(phone) != 10) {
		return false; 
	}
	for (int i = 0; phone[i] != '\0'; i++) {
		if (!isdigit(phone[i])) {
			return false; 
		}
	}
	return true;
}

bool isValidEmail(const char *email) {
	int length = strlen(email);

	if (length < 4 || strcmp(email + length - 4, ".com") != 0) {
		return false;
	}

	const char *atSymbol = strchr(email, '@');
	if (atSymbol == NULL || atSymbol == email || strchr(atSymbol + 1, '@') != NULL) {
		return false; 
	}

	for (int i = 0; email[i] != '\0'; i++) {
		if (!islower(email[i]) && email[i] != '@' && email[i] != '.') {
			return false;
		}
	}

	return true;
}
void initialize(AddressBook *addressBook) {
	addressBook->contactCount = 0;

	FILE *fp = fopen("contact.txt", "r");
	if (fp == NULL) {
		printf("Contact file not found. A new file will be created when contacts are saved.\n");
		return;
	}

	int i = 0;
	while (i < MAX_CONTACTS && fscanf(fp, " %[^,],%[^,],%[^\n]", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email) == 3) {
		i++;
		addressBook->contactCount++;
	}

	fclose(fp);

	if (i == MAX_CONTACTS) {
		printf("Warning: Maximum contact limit reached. Some contacts may not have been loaded.\n");
	}
}


void createContact(AddressBook *addressBook) {
    if (addressBook->contactCount >= MAX_CONTACTS) {
        printf("Address book is full!\n");
        return;
    }

    char newname[50];
    char newphone[20];
    char newemail[50];

    while (1) {
        printf("Enter the name: ");
        scanf(" %[^\n]", newname);

        if (isValidName(newname)) {
            break; 
        } else {
            printf("Invalid name! Name must contain only letters and spaces.\n");
        }
    }

    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcasecmp(addressBook->contacts[i].name, newname) == 0) {
            printf("The given name %s is already present!!\n", newname);
            return;
        }
    }

    while (1) {
        printf("Enter the phone number: ");
        scanf(" %[^\n]", newphone);

        if (isValidPhone(newphone)) {
            int phoneExists = 0;
            for (int i = 0; i < addressBook->contactCount; i++) {
                if (strcmp(addressBook->contacts[i].phone, newphone) == 0) {
                    phoneExists = 1;
                    break;
                }
            }

            if (phoneExists) {
                printf("The given phone number %s is already present!!\n", newphone);
            } else {
                break; 
            }
        } else {
            printf("Error: Phone number must contain exactly 10 digits!!\n");
        }
    }

    while (1) {
        printf("Enter the email: ");
        scanf(" %[^\n]", newemail);

        if (isValidEmail(newemail)) {
            int emailExists = 0;
            for (int i = 0; i < addressBook->contactCount; i++) {
                if (strcmp(addressBook->contacts[i].email, newemail) == 0) {
                    emailExists = 1;
                    break;
                }
            }

            if (emailExists) {
                printf("The given email %s is already present!!\n", newemail);
            } else {
                break; 
            }
        } else {
            printf("Error: Email must contain '@' and '.' and be in lowercase!!\n");
        }
    }

    strcpy(addressBook->contacts[addressBook->contactCount].name, newname);
    strcpy(addressBook->contacts[addressBook->contactCount].phone, newphone);
    strcpy(addressBook->contacts[addressBook->contactCount].email, newemail);

    addressBook->contactCount++;
    printf("Contact added successfully!!\n");
}
void searchContact(AddressBook *addressBook) {
	int option;
	printf("Select the option to search by:\n");
	printf("1. Name\n");
	printf("2. Phone\n");
	printf("3. Email\n");
	printf("Enter your choice: ");
	scanf("%d", &option);

	if (option < 1 || option > 3) {
		printf("Invalid option! Please select a number between 1 and 3.\n");
		return;
	}

	char searchTerm[50];
	printf("Enter the search term: ");
	scanf(" %[^\n]", searchTerm);

	int foundIndexes[MAX_CONTACTS]; 
	int foundCount = 0;

	
	switch (option) {
		case 1: 
			for (int i = 0; i < addressBook->contactCount; i++) {
				if (strstr(addressBook->contacts[i].name, searchTerm) != NULL) {
					foundIndexes[foundCount++] = i; 
				}
			}
			break;

		case 2: 
			for (int i = 0; i < addressBook->contactCount; i++) {
				if (strstr(addressBook->contacts[i].phone, searchTerm) != NULL) {
					foundIndexes[foundCount++] = i;
				}
			}
			break;

		case 3: 
			for (int i = 0; i < addressBook->contactCount; i++) {
				if (strstr(addressBook->contacts[i].email, searchTerm) != NULL) {
					foundIndexes[foundCount++] = i;
				}
			}
			break;

		default:
			printf("Invalid option!\n");
			return;
	}

	
	if (foundCount == 0) {
		printf("No contacts found matching '%s'.\n", searchTerm);
		return;
	}

	printf("\nMatching Contacts:\n");
	printf("------------------------------------\n");
	for (int i = 0; i < foundCount; i++) {
		int index = foundIndexes[i];
		switch (option) {
			case 1: 
				printf("%d. Name: %s\n", i + 1, addressBook->contacts[index].name);
				break;
			case 2: 
				printf("%d. Name: %s, Phone: %s\n", i + 1, addressBook->contacts[index].name, addressBook->contacts[index].phone);
				break;
			case 3: 
				printf("%d. Name: %s, Email: %s\n", i + 1, addressBook->contacts[index].name, addressBook->contacts[index].email);
				break;
		}
	}

	int selectedSerial;
	printf("\nEnter the serial number of the contact to view details: ");
	scanf("%d", &selectedSerial);

	if (selectedSerial < 1 || selectedSerial > foundCount) {
		printf("Invalid serial number!\n");
		return;
	}

	int selectedIndex = foundIndexes[selectedSerial - 1];
	printf("\nSelected Contact Details:\n");
	printf("Name: %s\n", addressBook->contacts[selectedIndex].name);
	printf("Phone: %s\n", addressBook->contacts[selectedIndex].phone);
	printf("Email: %s\n", addressBook->contacts[selectedIndex].email);
}

void editContact(AddressBook *addressBook) {
    int choice, foundCount = 0;
    int foundindex[100];
    printf("Choose option in which you want to edit:\n");
    printf("1. Name\n");
    printf("2. Phone\n");
    printf("3. Email\n");
    printf("Choose the option number: ");
    scanf("%d", &choice);

    char search[30];
    printf("Enter a character or a word to search: ");
    scanf(" %[^\n]", search);

    for (int i = 0; i < addressBook->contactCount; i++) {
        int match = 0;
        if (choice == 1 && (strchr(addressBook->contacts[i].name, search[0]) || strstr(addressBook->contacts[i].name, search))) {
            match = 1;
        } else if (choice == 2 && (strchr(addressBook->contacts[i].phone, search[0]) || strstr(addressBook->contacts[i].phone, search))) {
            match = 1;
        } else if (choice == 3 && (strchr(addressBook->contacts[i].email, search[0]) || strstr(addressBook->contacts[i].email, search))) {
            match = 1;
        }
        if (match) {
            foundindex[foundCount] = i;
            printf("%d\t%s\t%s\t%s\n", foundCount + 1, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
            foundCount++;
        }
    }

    if (foundCount == 0) {
        printf("No matching contacts found!!\n");
        return;
    }

    int selection;
    printf("\nEnter the number of the contact to edit: ");
    scanf("%d", &selection);

    if (selection < 1 || selection > foundCount) {
        printf("Invalid selection!\n");
        return;
    }

    int editIndex = foundindex[selection - 1];

    char new_name[50];
    char new_phone[20];
    char new_email[50];

    switch (choice) {
        case 1:
            while (1) {
                printf("Enter new name: ");
                scanf(" %[^\n]", new_name);

                if (isValidName(new_name)) {
                    break; 
                } else {
                    printf("Invalid name! Name must contain only letters and spaces.\n");
                }
            }
            strcpy(addressBook->contacts[editIndex].name, new_name);
            break;

        case 2:
            while (1) {
                printf("Enter new phone: ");
                scanf(" %[^\n]", new_phone);

                if (isValidPhone(new_phone)) {
                    break; 
                } else {
                    printf("Invalid phone number! Phone number must contain exactly 10 digits.\n");
                }
            }
            strcpy(addressBook->contacts[editIndex].phone, new_phone);
            break;

        case 3:
            while (1) {
                printf("Enter new email: ");
                scanf(" %[^\n]", new_email);

                if (isValidEmail(new_email)) {
                    break; 
                } else {
                    printf("Invalid email! Email must contain '@' and '.' and be in lowercase.\n");
                }
            }
            strcpy(addressBook->contacts[editIndex].email, new_email);
            break;
    }

    printf("Contact updated successfully!!!\n");
}
void deleteContact(AddressBook *addressBook) {
	if (addressBook->contactCount == 0) {
		printf("Address book is empty. No contacts to delete!!\n");
		return;
	}

	char choice;
	printf("Do you want to delete a contact? (Y/N): ");
	scanf(" %c", &choice);

	if (choice != 'Y' && choice != 'y') {
		printf("Deletion cancelled!!\n");
		return;
	}

	int option;
	printf("\nSelect the option to delete:\n1. Name\n2. Phone\n3. Mail\n");
	printf("Enter your choice: ");
	scanf("%d", &option);

	int foundIndexes[MAX_CONTACTS];
	int foundCount = 0;
	char search[50];

	while (1) {
		printf("Enter the a word or a number in which you want to search: ");
		scanf(" %[^\n]", search);

		foundCount = 0;

		printf("\nMatching Contacts:\n");
		printf("------------------------------------\n");

		for (int i = 0; i < addressBook->contactCount; i++) {
			if ((option == 1 && strstr(addressBook->contacts[i].name, search) != NULL) ||
					(option == 2 && strstr(addressBook->contacts[i].phone, search) != NULL) ||
					(option == 3 && strstr(addressBook->contacts[i].email, search) != NULL)) {
				foundIndexes[foundCount++] = i;
				printf("%d. Name: %s  Phone: %s  Mail: %s\n", foundCount, addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
			}
		}

		if (foundCount == 0) {
			printf("\nNo contacts found containing '%s'.\n", search);
			printf("Do you want to try again? (Y/N): ");
			scanf(" %c", &choice);
			if (choice != 'Y' && choice != 'y') {
				printf("Deletion cancelled!!.\n");
				return;
			}
		} else {
			break;
		}
	}

	int selectedSi;
	printf("\nEnter the Serial number from the list to delete: ");
	scanf("%d", &selectedSi);

	if (selectedSi < 1 || selectedSi > foundCount) {
		printf("Invalid input!!\n");
		return;
	}

	int selectedIndex = foundIndexes[selectedSi - 1];

	printf("Are you sure you want to delete this contact? (Y/N): ");
	scanf(" %c", &choice);

	if (choice != 'Y' && choice != 'y') {
		printf("Deletion cancelled!!\n");
		return;
	}

	for (int i = selectedIndex; i < addressBook->contactCount - 1; i++) {
		addressBook->contacts[i] = addressBook->contacts[i + 1];
	}
	addressBook->contactCount--;

	printf("Contact deleted successfully!!\n");
}

void saveContact(AddressBook *addressBook)
{
	FILE *fp = fopen("contact.txt", "w");
	if (fp == NULL) {
		printf("Error opening file for saving contacts!!\n");
		return;
	}

	for (int i = 0; i < addressBook->contactCount; i++) {
		fprintf(fp, "%s,%s,%s\n", addressBook->contacts[i].name, addressBook->contacts[i].phone, addressBook->contacts[i].email);
	}

	fclose(fp);
	printf("Contacts saved successfully!!\n");
}

