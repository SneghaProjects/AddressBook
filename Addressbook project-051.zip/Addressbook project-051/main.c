#include "contact.h"

int main()
{
    AddressBook addressBook;
    initialize(&addressBook);

    while (1)
    {
        int option;
        printf("\nSelect an option from the menu:\n");
        printf("1. List Contacts\n");
        printf("2. Add Contact\n");
        printf("3. Search Contact\n");
        printf("4. Edit Contact\n");
        printf("5. Delete Contact\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &option) != 1)  // Handle non-integer input
        {
            printf("Invalid input... Please enter a number between 1 and 6!\n");
            while (getchar() != '\n');  // Clear input buffer
            continue;
        }

        switch (option)
        {
            case 1:
                listContacts(&addressBook);
                break;
            case 2:
                createContact(&addressBook);
                break;
            case 3:
                searchContact(&addressBook);
                break;
            case 4:
                editContact(&addressBook);
                break;
            case 5:
                deleteContact(&addressBook);
                break;
            case 6:
                printf("Exiting the Address Book!!\n");
                saveContact(&addressBook);
                return 0;
            default:
                printf("Invalid input... Please enter a number between 1 and 6!\n");
        }
    }
}
